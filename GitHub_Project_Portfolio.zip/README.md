# Okeowo Adewunmi — Project Portfolio

Machine learning, network security, data engineering and academic projects.

Descriptions distinguish implemented methods from completed experiments. Project support for a dataset does not imply a completed run. Draft security scores are omitted pending verification.

## Projects

- [Network Flow Extraction and Malware Detection](network-flow-extraction-and-malware-detection/README.md)
- [Encrypted and Unencrypted Malware Traffic Classification](encrypted-and-unencrypted-malware-traffic-classification/README.md)
- [Two-Stage Confidence-Gated Malware Detection](two-stage-confidence-gated-malware-detection/README.md)
- [Open-Set Traffic Classification and CNN State-Mixing Variants](open-set-traffic-classification-and-cnn-state-mixing-variants/README.md)
- [HTTPS Traffic Classification Pipelines](https-traffic-classification-pipelines/README.md)
- [Self-Supervised Malware Traffic Classification](self-supervised-malware-traffic-classification/README.md)
- [ETGuard Sequence Classification and Alternative Baseline](etguard-sequence-classification-and-alternative-baseline/README.md)
- [IoT Malware Traffic Data Preparation](iot-malware-traffic-data-preparation/README.md)
- [Residential Property Price Prediction](residential-property-price-prediction/README.md)
- [Housing Prediction with Economic Indicators](housing-prediction-with-economic-indicators/README.md)
- [Telecom Customer Churn Prediction](telecom-customer-churn-prediction/README.md)
- [Telecommunications Campaign Response Classification](telecommunications-campaign-response-classification/README.md)
- [Retail Product and Customer Review Analysis](retail-product-and-customer-review-analysis/README.md)
- [Distributed Movie Ratings Analysis](distributed-movie-ratings-analysis/README.md)
- [Football Match Statistics Portfolio](football-match-statistics-portfolio/README.md)
- [Hotel Room Demand Forecasting](hotel-room-demand-forecasting/README.md)
- [Customer Churn Score Modelling](customer-churn-score-modelling/README.md)
- [Cybersecurity Event Forecasting](cybersecurity-event-forecasting/README.md)
- [Sound Festival Schedule Builder](sound-festival-schedule-builder/README.md)
- [Student Lifestyle Dashboard](student-lifestyle-dashboard/README.md)
- [Sales Analysis Dashboards](sales-analysis-dashboards/README.md)

## Attribution
Research adaptations retain upstream notices where supplied. No blanket license is assigned to third-party code or datasets.
